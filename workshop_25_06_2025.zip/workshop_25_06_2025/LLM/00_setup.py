# Databricks notebook source
# MAGIC %md
# MAGIC <img src="https://github.com/Databricks-BR/lab_genai/blob/main/img/header.png?raw=true" width=100%>
# MAGIC
# MAGIC # Hands-On Importando os dados
# MAGIC
# MAGIC Treinamento Hands-on na plataforma Databricks com foco nas funcionalidades de IA Generativa.
# MAGIC </br></br></br>
# MAGIC
# MAGIC ## Objetivos do Exercício
# MAGIC
# MAGIC O objetivo desse laboratório é importar os dados que serão utilizados nos exercícios.
# MAGIC </br></br></br>
# MAGIC
# MAGIC ## Criação do database
# MAGIC
# MAGIC Primeiro, vamos criar um database (ou schema – esses nomes são usados como sinônimos). Esse funcionará como um conteiner para guardar os dados que iremos utilizar durante os exercícios.
# MAGIC
# MAGIC </br></br>
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC USE CATALOG workspace; -- mudar para o catalog do treinamento
# MAGIC USE DATABASE db_rodrigolima82; -- mudar para o database do treinamento

# COMMAND ----------

# MAGIC %md
# MAGIC ## Importação dos Arquivos
# MAGIC
# MAGIC Agora, precisamos carregar os dados que usaremos nos próximos laboratórios.
# MAGIC
# MAGIC Esse conjunto consiste basicamente de quatro tabelas:
# MAGIC - **Avaliações:** conteúdo das avaliações
# MAGIC - **Clientes:** dados cadastrais e consumo dos clientes
# MAGIC - **Produtos:** dados de registro e descrições dos produto
# MAGIC - **FAQ:** perguntas e respostas frequentes em nosso website
# MAGIC
# MAGIC

# COMMAND ----------

def creating_tables(table_name, url):
    import pandas as pd

    df = pd.read_csv(url)
    
    print(f"creating `{table_name}` raw table")
    spark.createDataFrame(df).write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(table_name)

# COMMAND ----------

# Creating the `avaliacoes` table from the specified CSV URL
creating_tables("avaliacoes", "https://raw.githubusercontent.com/Databricks-BR/lab_genai/refs/heads/main/dados/avaliacoes.csv")

# Creating the `clientes` table from the specified CSV URL
creating_tables("clientes", "https://raw.githubusercontent.com/Databricks-BR/lab_genai/refs/heads/main/dados/clientes.csv")

# Creating the `faq` table from the specified CSV URL
creating_tables("faq", "https://raw.githubusercontent.com/Databricks-BR/lab_genai/refs/heads/main/dados/faq.csv")

# Creating the `produtos` table from the specified CSV URL
creating_tables("produtos", "https://raw.githubusercontent.com/Databricks-BR/lab_genai/refs/heads/main/dados/produtos.csv")