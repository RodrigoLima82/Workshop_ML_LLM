# Databricks notebook source
# MAGIC %md
# MAGIC ## Notebook para realizar a configuração do ambiente

# COMMAND ----------

##### Preencha com o nome do catálogo
catalogo = "dev_rodrigo"

##### Preencha com o nome do prefixo do schema
prefix_db = "workshop_" # treinamento_rodrigo_oliveira

#### Preencher como true caso tenham um schema comum para criarmos a tabela de transacoes
criar_schema_comum = False

model_name = "churn_model_workshop"