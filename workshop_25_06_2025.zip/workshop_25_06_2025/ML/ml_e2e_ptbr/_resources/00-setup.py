# Databricks notebook source
# MAGIC %run "./setup"

# COMMAND ----------

#dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.dropdown("reset_all_data", "false", ["true", "false"], "Reset all data")
dbutils.widgets.dropdown("setup_inference_data", "false", ["true", "false"], "Setup inference data")
reset_all_data = dbutils.widgets.get("reset_all_data") == "true"
setup_inference_data = dbutils.widgets.get("setup_inference_data") == "true"

# COMMAND ----------

###################### Mudar essas variáveis ######################

#workshops_databricks
catalog_prod = catalogo
catalog_dev = catalogo
experiment_name = "churn_model" + unique_name()
dbName = db = schema

######################
bronze_table_name = "churn_bronze_customers"
volume_name = "landing"
volume_path = f"/Volumes/{catalog_prod}/{schema}/{volume_name}"
dbutils.widgets.text("catalog_prod", catalog_prod)
dbutils.widgets.text("catalog_dev", catalog_dev)
dbutils.widgets.text("schema", schema)
catalog_prod = dbutils.widgets.get("catalog_prod")
catalog_dev = dbutils.widgets.get("catalog_dev")
schema = dbName = db =  dbutils.widgets.get("schema")

# COMMAND ----------

# MAGIC %run ./00-global-setup-v2

# COMMAND ----------

import mlflow
import pandas as pd
import re
#remove warnings for nicer display
import warnings
warnings.filterwarnings("ignore")
import logging
logging.getLogger("mlflow").setLevel(logging.ERROR)

from mlflow import MlflowClient

# COMMAND ----------

# Set UC Model Registry as default
mlflow.set_registry_uri("databricks-uc")
client = MlflowClient()

# COMMAND ----------

def creating_table_churn(table_name):
    # import requests
    # from io import StringIO
    # import re
    import pandas as pd

    url = "https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv"
    df = pd.read_csv(url)

    # # Dataset under apache license: https://github.com/IBM/telco-customer-churn-on-icp4d/blob/master/LICENSE
    # csv = requests.get("https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv").text
    # df = pd.read_csv(StringIO(csv), sep=",")
        
    def cleanup_column(pdf):
      # Clean up column names
      pdf.columns = [re.sub(r'(?<!^)(?=[A-Z])', '_', name).lower().replace("__", "_") for name in pdf.columns]
      pdf.columns = [re.sub(r'[\(\)]', '', name).lower() for name in pdf.columns]
      pdf.columns = [re.sub(r'[ -]', '_', name).lower() for name in pdf.columns]
      return pdf.rename(columns = {'streaming_t_v': 'streaming_tv', 'customer_i_d': 'customer_id'})

    df = cleanup_column(df)
    
    print(f"creating `{table_name}` raw table")
    spark.createDataFrame(df).write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(table_name)

# COMMAND ----------

# DBTITLE 1,Create Raw/Bronze customer data from IBM Telco public dataset and sanitize column name
table_training = f"{catalog_prod}.{schema}.{bronze_table_name}"
if reset_all_data or not spark.catalog.tableExists(table_training):
  creating_table_churn(table_training)

# COMMAND ----------

def delete_feature_store_table(catalog_dev, db, feature_table_name):
  from databricks.feature_engineering import FeatureEngineeringClient
  fe = FeatureEngineeringClient()
  try:
    # Drop existing table from Feature Store
    fe.drop_table(name=f"{catalog_dev}.{db}.{feature_table_name}")
    # Delete underyling delta tables
    spark.sql(f"DROP TABLE IF EXISTS {catalog_dev}.{db}.{feature_table_name}")
    print(f"Dropping Feature Table {catalog_dev}.{db}.{feature_table_name}")
  except ValueError as ve:
    print(f"Feature Table {catalog_dev}.{db}.{feature_table_name} doesn't exist")

# COMMAND ----------

if setup_inference_data:
  if not spark.catalog.tableExists(f"{catalog_dev}.{db}.mlops_churn_inference"):
    # Define the parameters to pass to the notebook
    notebook_params = {
      "catalog_dev": catalogo,
      "schema": schema,
      "data_output" : f"churn_inference",
    }

    # Execute another notebook with the specified parameters
    notebook_path = "../01-mlops-quickstart/01_feature_engineering"
    dbutils.notebook.run(notebook_path, 60, notebook_params)