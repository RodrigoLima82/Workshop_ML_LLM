# Databricks notebook source
# MAGIC %md
# MAGIC # Feature Engineering
# MAGIC Nosso primeiro passo é analisar os dados e construir os recursos que usaremos para treinar nosso modelo. Vamos ver como isso pode ser feito.
# MAGIC <img src="https://github.com/databricks-demos/dbdemos-resources/blob/main/images/product/mlops/mlops-uc-end2end-1.png?raw=true" width="1200">
# MAGIC
# MAGIC <!-- Collect usage data (view). Remove it to disable collection or disable tracker during installation. View README for more details.  -->
# MAGIC <img width="1px" src="https://ppxrzfxige.execute-api.us-west-2.amazonaws.com/v1/analytics?category=data-science&org_id=984752964297111&notebook=%2F01-mlops-quickstart%2F01_feature_engineering&demo_name=mlops-end2end&event=VIEW&path=%2F_dbdemos%2Fdata-science%2Fmlops-end2end%2F01-mlops-quickstart%2F01_feature_engineering&version=1">

# COMMAND ----------

# DBTITLE 1,Instalar o client mais recente de feature engineering para UC [para MLR < 13.2] e SDK Python do Databricks
#%pip install --quiet mlflow==2.14.0
#dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ../_resources/00-setup

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("catalog", catalog_prod)
dbutils.widgets.text("schema", schema)
bronze_table = "churn_bronze_customers"
dbutils.widgets.text("bronze_table", bronze_table)

# COMMAND ----------

# MAGIC %md
# MAGIC Parâmetro para ser utilizado o mesmo notebook para o feature engineering do treinamento e da inferência

# COMMAND ----------


table_output = ""
try:
    # Receber o conteúdo de um parâmetro passado por outro notebook
    data_output = dbutils.widgets.get("data_output")
    table_output = data_output
except:
    table_output = "churn_training"  

# COMMAND ----------

# MAGIC %md
# MAGIC ## Análise Exploratória de Dados
# MAGIC Para entender melhor os dados, o que precisa ser limpo, pré-processado, etc.
# MAGIC - **Use as ferramentas de visualização nativas do Databricks**
# MAGIC   - Após executar uma consulta SQL em uma célula do notebook, use a aba `+` para adicionar gráficos e visualizar os resultados.
# MAGIC - Traga sua própria biblioteca de visualização preferida (por exemplo, seaborn, plotly)

# COMMAND ----------

spark.sql(f"select * from {catalog_prod}.{schema}.{bronze_table}").display()

# COMMAND ----------

churnDF = spark.read.table(f"{catalog_prod}.{schema}.{bronze_table}").pandas_api()
churnDF["internet_service"].value_counts().plot.pie()

# COMMAND ----------

# DBTITLE 1,Ler a tabela Delta Bronze usando Spark
churnDF = spark.read.table(f"{catalog_prod}.{schema}.{bronze_table}")
display(churnDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Definir função de featurização
# MAGIC
# MAGIC Vamos definir uma função para limpar os dados e implementar a lógica de featurização. Faremos:
# MAGIC
# MAGIC 1. Calcular o número de serviços opcionais
# MAGIC 2. Fornecer rótulos significativos
# MAGIC 3. Imputar valores nulos
# MAGIC
# MAGIC _Isso também pode funciona para recursos baseados em streaming_

# COMMAND ----------

# MAGIC %md
# MAGIC ### Usando a API Pandas no Spark
# MAGIC
# MAGIC Como nossa equipe de Cientistas de Dados está familiarizada com Pandas, usaremos a [API pandas no spark](https://spark.apache.org/docs/latest/api/python/reference/pyspark.pandas/index.html) para escalar o código `pandas`. As instruções do Pandas serão convertidas no mecanismo do Spark nos bastidores e distribuídas em escala.
# MAGIC
# MAGIC *Nota: A API Pandas no Spark costumava ser chamada de Koalas. A partir do `spark 3.2`, Koalas está embutido e podemos obter um DataFrame Pandas usando `pandas_api()` [Detalhes](https://spark.apache.org/docs/latest/api/python/migration_guide/koalas_to_pyspark.html).*

# COMMAND ----------

# DBTITLE 1,Define featurization function
import pyspark.sql.functions as F
from pyspark.sql import DataFrame

def clean_churn_features(dataDF: DataFrame) -> DataFrame:
  """
  Função simples de limpeza utilizando a API pandas
  """

  # Converter para dataframe pandas no spark
  data_psdf = dataDF.pandas_api()

  # Converter algumas colunas
  data_psdf["senior_citizen"] = data_psdf["senior_citizen"].map({1 : "Sim", 0 : "Não"})
  data_psdf = data_psdf.astype({"total_charges": "double", "senior_citizen": "string"})

  # Preencher alguns valores numéricos ausentes com 0
  data_psdf = data_psdf.fillna({"tenure": 0.0})
  data_psdf = data_psdf.fillna({"monthly_charges": 0.0})
  data_psdf = data_psdf.fillna({"total_charges": 0.0})

  def sum_optional_services(df):
      """Contar o número de serviços opcionais habilitados, como streaming de TV"""
      cols = ["online_security", "online_backup", "device_protection", "tech_support",
              "streaming_tv", "streaming_movies"]
      return sum(map(lambda c: (df[c] == "Sim"), cols))

  data_psdf["num_optional_services"] = sum_optional_services(data_psdf)

  # Retornar o dataframe Spark limpo
  return data_psdf.to_spark()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calcular features e escrever tabela com features e labels
# MAGIC
# MAGIC Uma vez que nossas features estejam prontas, vamos salvá-las junto com os labels como uma tabela Delta Lake. Isso pode ser recuperado mais tarde para o treinamento do modelo.
# MAGIC
# MAGIC Nesta demonstração rápida, veremos como treinar um modelo usando este conjunto de dados rotulado salvo como uma tabela Delta Lake e capturar a linhagem da tabela-modelo. A linhagem do modelo traz rastreabilidade e governança em nossa implantação, permitindo-nos saber qual modelo depende de qual conjunto de tabelas de features.
# MAGIC
# MAGIC A Databricks possui uma capacidade de Feature Store que é fortemente integrada à plataforma. Qualquer tabela Delta Lake com uma chave primária pode ser usada como uma tabela de Feature Store para treinamento de modelos, bem como para serviço em lote e online. 

# COMMAND ----------

churn_features = clean_churn_features(churnDF)
display(churn_features)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Escrever tabela para treinamento
# MAGIC
# MAGIC Escreva os dados rotulados que possuem as features e labels preparados como uma Tabela Delta. Usaremos esta tabela posteriormente para treinar o modelo para prever churn.

# COMMAND ----------

# Especificar divisão de treino-validação-teste
train_ratio, val_ratio, test_ratio = 0.7, 0.2, 0.1
churn_features = (churn_features.withColumn("random", F.rand(seed=42))
                                .withColumn("split",
                                            F.when(F.col("random") < train_ratio, "train")
                                            .when(F.col("random") < train_ratio + val_ratio, "validate")
                                            .otherwise("test"))
                                .drop("random"))

# Escrever tabela para treinamento
(churn_features.write.mode("overwrite")
               .option("overwriteSchema", "true")
               .saveAsTable(f"{catalog_dev}.{schema}.{table_output}"))

# Adicionar comentário à tabela
spark.sql(f"""COMMENT ON TABLE {catalog_dev}.{schema}.{table_output} IS \'As features nesta tabela são derivadas da tabela mlops_churn_bronze_customers no lakehouse. 
              Criamos features de serviço, limpamos seus nomes. Nenhuma agregação foi realizada.'""")

# COMMAND ----------

print(f"Tabela {catalog_dev}.{schema}.{table_output} carregada com sucesso.")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC É isso aí! As features rotuladas estão agora prontas para serem usadas no treinamento.