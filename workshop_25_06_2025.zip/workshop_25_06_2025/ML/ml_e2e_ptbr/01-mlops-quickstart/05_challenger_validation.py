# Databricks notebook source
# MAGIC %md
# MAGIC # Validação do modelo Challenger
# MAGIC
# MAGIC Este notebook realiza tarefas de validação no modelo candidato __Challenger__.
# MAGIC
# MAGIC Ele passa por algumas etapas para validar o modelo antes de rotulá-lo (definindo seu alias) como `Challenger`.
# MAGIC
# MAGIC Quando as organizações começam a implementar processos de MLOps, elas devem considerar ter um "humano no loop" para realizar análises visuais para validar modelos antes de promovê-los. À medida que se familiarizam com o processo, podem considerar automatizar as etapas em um __Workflow__. Os benefícios da automação são garantir que essas verificações de validação sejam sistematicamente realizadas antes que novos modelos sejam integrados aos pipelines de inferência ou implantados para serviço em tempo real. Claro, as organizações podem optar por manter um "humano no loop" em qualquer parte do processo e implementar o grau de automação que atenda às suas necessidades de negócios.
# MAGIC
# MAGIC <img src="https://github.com/databricks-demos/dbdemos-resources/blob/main/images/product/mlops/mlops-uc-end2end-4.png?raw=true" width="1200">
# MAGIC
# MAGIC *Nota: em uma configuração típica de mlops, isso seria executado como parte de um trabalho automatizado para validar novos modelos. Para este simples demo, vamos executá-lo como um notebook interativo.*
# MAGIC
# MAGIC <!-- Coletar dados de uso (visualização). Remova para desativar a coleta ou desative o rastreador durante a instalação. Veja o README para mais detalhes. -->
# MAGIC <img width="1px" src="https://ppxrzfxige.execute-api.us-west-2.amazonaws.com/v1/analytics?category=data-science&org_id=984752964297111&notebook=%2F01-mlops-quickstart%2F04_challenger_validation&demo_name=mlops-end2end&event=VIEW&path=%2F_dbdemos%2Fdata-science%2Fmlops-end2end%2F01-mlops-quickstart%2F04_challenger_validation&version=1">

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ## Verificações Gerais de Validação
# MAGIC
# MAGIC <!--img style="float: right" src="https://github.com/QuentinAmbard/databricks-demo/raw/main/retail/resources/images/churn-mlflow-webhook-1.png" width=600 -->
# MAGIC
# MAGIC No contexto de MLOps, há mais testes do que simplesmente quão preciso um modelo será. Para garantir a estabilidade do nosso sistema de ML e a conformidade com quaisquer requisitos regulatórios, submeteremos cada modelo adicionado ao registro a uma série de verificações de validação. Estas incluem, mas não se limitam a:
# MAGIC <br>
# MAGIC * __Documentação do modelo__
# MAGIC * __Inferência em dados de produção__
# MAGIC * __Teste Champion-Challenger para garantir que os KPIs de negócios sejam aceitáveis__
# MAGIC
# MAGIC Neste notebook, exploramos algumas abordagens para realizar esses testes e como podemos adicionar metadados aos nossos modelos com tags, indicando se eles passaram ou não em um determinado teste.
# MAGIC
# MAGIC Esta parte é tipicamente específica para sua linha de negócios e requisitos de qualidade.
# MAGIC
# MAGIC Para cada teste, adicionaremos informações usando tags para saber o que foi validado no modelo. Também podemos adicionar Comentários a um modelo, se necessário.

# COMMAND ----------

# %pip install --quiet mlflow==2.14.0
# dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ../_resources/00-setup

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("catalog", catalog_prod)
dbutils.widgets.text("schema", schema)
training_table = f"{catalog_dev}.{schema}.churn_training"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Buscar informações do modelo
# MAGIC
# MAGIC Vamos buscar as informações do modelo para o modelo __Challenger__ do Unity Catalog.

# COMMAND ----------

# Estamos interessados em validar o modelo Challenger
model_alias = "Challenger"
model_name = f"{catalog_prod}.{schema}.churn_model"

client = MlflowClient()
model_details = client.get_model_version_by_alias(model_name, model_alias)
model_version = int(model_details.version)

print(f"Validando o modelo {model_alias} para {model_name} na versão do modelo {model_version}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Model checks

# COMMAND ----------

# MAGIC %md
# MAGIC #### Verificação de descrição
# MAGIC
# MAGIC O cientista de dados forneceu uma descrição do modelo que está sendo submetido?

# COMMAND ----------

# Se não houver descrição ou um número insuficiente de caracteres, marque de acordo
if not model_details.description:
  has_description = False
  print("Por favor, adicione uma descrição ao modelo")
elif not len(model_details.description) > 20:
  has_description = False
  print("Por favor, adicione uma descrição detalhada ao modelo (mínimo de 40 caracteres).")
else:
  has_description = True

print(f'O modelo {model_name} versão {model_details.version} tem descrição: {has_description}')
client.set_model_version_tag(name=model_name, version=str(model_details.version), key="has_description", value=has_description)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Métrica de desempenho do modelo
# MAGIC
# MAGIC Queremos validar a métrica de desempenho do modelo. Tipicamente, queremos comparar essa métrica obtida para o modelo Desafiante com a do modelo Champion. Como ainda não registramos um modelo Champion, vamos apenas recuperar a métrica para o modelo Desafiante sem fazer uma comparação.
# MAGIC
# MAGIC O modelo registrado captura informações sobre a execução do experimento MLflow, onde as métricas do modelo foram registradas durante o treinamento. Isso lhe dá rastreabilidade desde o modelo implantado até as execuções de treinamento iniciais.
# MAGIC
# MAGIC Aqui, usaremos a pontuação F1 para os dados de teste fora da amostra que foram separados no momento do treinamento.

# COMMAND ----------

model_run_id = model_details.run_id
f1_score = mlflow.get_run(model_run_id).data.metrics['test_f1_score']

try:
    # Compare a pontuação f1 do challenger com o Champion existente, se houver
    champion_model = client.get_model_version_by_alias(model_name, "Champion")
    champion_f1 = mlflow.get_run(champion_model.run_id).data.metrics['test_f1_score']
    print(f'Pontuação f1 do Champion: {champion_f1}. Pontuação f1 do Challenger: {f1_score}.')
    metric_f1_passed = f1_score >= champion_f1
except:
    print(f"Nenhum Champion encontrado. Aceite o modelo, pois é o primeiro.")
    metric_f1_passed = True

print(f'Modelo {model_name} versão {model_details.version} metric_f1_passed: {metric_f1_passed}')
# Marcar que a verificação da métrica F1 foi aprovada
client.set_model_version_tag(name=model_name, version=model_details.version, key="metric_f1_passed", value=metric_f1_passed)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Resultados da validação
# MAGIC
# MAGIC É isso aí! Demonstramos algumas verificações simples no modelo. Vamos dar uma olhada nos resultados da validação.

# COMMAND ----------

results = client.get_model_version(model_name, model_version)
results.tags

# COMMAND ----------

# MAGIC %md
# MAGIC ## Promovendo o Challenger para Champion
# MAGIC
# MAGIC Quando estamos satisfeitos com os resultados do modelo __Challenger__, podemos promovê-lo a Champion. Isso é feito definindo seu alias como `@Champion`. Pipelines de inferência que carregam o modelo usando o alias `@Champion` carregarão este novo modelo. O alias do modelo Champion anterior, se houver, será automaticamente removido. O modelo mantém seu alias `@Challenger` até que um novo modelo Challenger seja implantado com o alias para substituí-lo.

# COMMAND ----------

if results.tags["has_description"] and results.tags["metric_f1_passed"]:
  print('registrar modelo como Champion!')
  client.set_registered_model_alias(
    name=model_name,
    alias="Champion",
    version=model_version
  )
  client.delete_registered_model_alias(
    name=model_name,
    alias="Challenger"
  )
else:
  raise Exception("Modelo não está pronto para promoção")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Parabéns, nosso modelo agora está validado e promovido adequadamente
# MAGIC
# MAGIC Agora temos a certeza de que nosso modelo está pronto para ser usado em pipelines de inferência e em endpoints de serviço em tempo real, pois atende aos nossos padrões de validação.
# MAGIC
# MAGIC Próximo: [Executar inferência em lote a partir do nosso modelo Champion recém-promovido]($./05_batch_inference)