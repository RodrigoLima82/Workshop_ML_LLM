# Databricks notebook source
# MAGIC %md
# MAGIC # Demonstração de MLOps de ponta a ponta com MLFlow, Auto ML e Modelos no Unity Catalog
# MAGIC
# MAGIC ## Desafios ao mover um projeto de ML para produção
# MAGIC
# MAGIC Mover um projeto de ML de um notebook autônomo para um pipeline de dados em nível de produção é complexo e requer múltiplas competências.
# MAGIC
# MAGIC Ter um modelo funcionando em um notebook não é suficiente. Precisamos cobrir todo o ciclo de vida do projeto de ML e resolver os seguintes desafios:
# MAGIC
# MAGIC * Atualizar dados ao longo do tempo (pipeline de ingestão em nível de produção)
# MAGIC * Como salvar, compartilhar e reutilizar recursos de ML na organização
# MAGIC * Como garantir que uma nova versão do modelo respeite os padrões de qualidade e não quebre o pipeline
# MAGIC * Governança do modelo: o que está implantado, como é treinado, por quem, com quais dados?
# MAGIC * Como monitorar e re-treinar o modelo...
# MAGIC
# MAGIC Além disso, esses projetos geralmente envolvem múltiplas equipes, criando fricções e potenciais silos:
# MAGIC
# MAGIC * Engenheiros de Dados, responsáveis por ingerir, preparar e expor os dados
# MAGIC * Cientistas de Dados, especialistas em análise de dados, construção de modelos de ML
# MAGIC * Engenheiros de ML, configurando os pipelines de infraestrutura de ML (semelhante ao DevOps)
# MAGIC
# MAGIC Isso tem um impacto real nos negócios, desacelerando projetos e impedindo que sejam implantados em produção e trazendo ROI.
# MAGIC
# MAGIC ## O que é MLOps?
# MAGIC
# MAGIC MLOps é um conjunto de padrões, ferramentas, processos e metodologias que visam otimizar o tempo, a eficiência e a qualidade, garantindo a governança em projetos de ML.
# MAGIC
# MAGIC MLOps orquestra o ciclo de vida de um projeto e adiciona a cola necessária entre os componentes e equipes para implementar suavemente tais pipelines de ML.
# MAGIC
# MAGIC A Databricks está exclusivamente posicionada para resolver esse desafio com o padrão Lakehouse. Não só reunimos Engenheiros de Dados, Cientistas de Dados e Engenheiros de ML em uma plataforma única, mas também fornecemos ferramentas para orquestrar projetos de ML e acelerar a ida para produção.
# MAGIC
# MAGIC ## Passo a passo do processo de MLOps
# MAGIC
# MAGIC Nesta demonstração rápida, vamos percorrer algumas etapas comuns no processo de MLOps. O resultado final deste processo é um modelo usado para detectar a evasão de clientes, que é:
# MAGIC * preparando recursos
# MAGIC * treinando um modelo para implantação
# MAGIC * registrando o modelo para que seu uso seja governado
# MAGIC * validando o modelo em uma análise de campeão-desafiante
# MAGIC * invocando um modelo de ML treinado como um UDF do pySpark
# MAGIC
# MAGIC <img src="https://github.com/databricks-demos/dbdemos-resources/blob/main/images/product/mlops/mlops-uc-end2end-0.png?raw=true" width="1200">
# MAGIC
# MAGIC <!-- Coletar dados de uso (visualização). Remova para desativar a coleta ou desative o rastreador durante a instalação. Veja o README para mais detalhes. -->
# MAGIC <img width="1px" src="https://ppxrzfxige.execute-api.us-west-2.amazonaws.com/v1/analytics?category=data-science&org_id=984752964297111&notebook=%2F01-mlops-quickstart%2F00_mlops_end2end_quickstart_presentation&demo_name=mlops-end2end&event=VIEW&path=%2F_dbdemos%2Fdata-science%2Fmlops-end2end%2F01-mlops-quickstart%2F00_mlops_end2end_quickstart_presentation&version=1">

# COMMAND ----------

# DBTITLE 1,Rodar as configurações para criar seu schema e fazer download dos dados
# MAGIC %run ../_resources/00-setup $reset_all_data=true

# COMMAND ----------

# MAGIC %md
# MAGIC ## Detecção de churn de clientes
# MAGIC
# MAGIC Para explorar MLOps, implementaremos um modelo de churn de clientes.
# MAGIC
# MAGIC Nossa equipe de marketing nos pediu para criar um painel que acompanhe a evolução do risco de churn. Além disso, precisamos fornecer à nossa equipe de renovação uma lista diária de clientes em risco de churn para aumentar nossa receita final.
# MAGIC
# MAGIC Nossa equipe de Engenharia de Dados nos forneceu um conjunto de dados que coleta informações sobre nossa base de clientes, incluindo informações de churn. É aqui que nossa implementação começa.
# MAGIC
# MAGIC Vamos ver como podemos implementar tal modelo, mas também fornecer à nossa equipe de marketing e renovação painéis para acompanhar e analisar nossa previsão de churn.
# MAGIC

# COMMAND ----------

print(catalog_prod)
print(schema)

# COMMAND ----------

# DBTITLE 1,Explorando nosso conjunto de dados de clientes
churnDF = spark.table(f"{catalog_prod}.{schema}.churn_bronze_customers")
display(churnDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ##  Feature Engineering
# MAGIC Nosso primeiro trabalho é analisar os dados e preparar um conjunto de recursos.
# MAGIC
# MAGIC Próximo: [Analisar os dados e preparar recursos]($./01_feature_engineering)