# Databricks notebook source
# MAGIC %md
# MAGIC # Criação de Modelo Baseline com AutoML
# MAGIC Agora, vamos criar um modelo baseline com AutoML.
# MAGIC
# MAGIC <img src="https://github.com/databricks-demos/dbdemos-resources/blob/main/images/product/mlops/mlops-uc-end2end-2.png?raw=true" width="1200">
# MAGIC
# MAGIC <!-- Coletar dados de uso (visualização). Remova para desativar a coleta ou desative o rastreador durante a instalação. Veja o README para mais detalhes. -->
# MAGIC <img width="1px" src="https://ppxrzfxige.execute-api.us-west-2.amazonaws.com/v1/analytics?category=data-science&org_id=984752964297111&notebook=%2F01-mlops-quickstart%2F02_automl_best_run&demo_name=mlops-end2end&event=VIEW&path=%2F_dbdemos%2Fdata-science%2Fmlops-end2end%2F01-mlops-quickstart%2F02_automl_best_run&version=1">

# COMMAND ----------

# DBTITLE 1,Install latest feature engineering client for UC [for MLR < 13.2] and databricks python sdk
#%pip install --quiet mlflow==2.14.0
#dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ../_resources/00-setup

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("catalog", catalog_prod)
dbutils.widgets.text("schema", schema)
training_table = f"{catalog_dev}.{schema}.churn_training"

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ## Acelerando a criação de modelos de Churn usando Databricks AutoML
# MAGIC ### Uma solução de caixa de vidro que capacita equipes de dados sem tirar o controle
# MAGIC
# MAGIC Databricks simplifica a criação de modelos e MLOps. No entanto, iniciar novos projetos de ML ainda pode ser longo e ineficiente.
# MAGIC
# MAGIC Em vez de criar o mesmo boilerplate para cada novo projeto, o Databricks AutoML pode gerar automaticamente modelos de última geração para classificações, regressão e previsão.
# MAGIC
# MAGIC <img width="1000" src="https://github.com/QuentinAmbard/databricks-demo/raw/main/retail/resources/images/auto-ml-full.png"/>
# MAGIC
# MAGIC <img style="float: right" width="600" src="https://github.com/QuentinAmbard/databricks-demo/raw/main/retail/resources/images/churn-auto-ml.png"/>
# MAGIC
# MAGIC Os modelos podem ser implantados diretamente ou, em vez disso, aproveitar os notebooks gerados para iniciar projetos com as melhores práticas, economizando semanas de esforço.
# MAGIC
# MAGIC ### Usando Databricks AutoML com nosso conjunto de dados de Churn
# MAGIC
# MAGIC AutoML está disponível no espaço "Machine Learning". Tudo o que precisamos fazer é iniciar um novo experimento AutoML e selecionar a tabela que acabamos de criar (`dbdemos.schema.mlops_churn_training`).
# MAGIC
# MAGIC Nosso alvo de previsão é a coluna `churn`.
# MAGIC
# MAGIC Clique em Iniciar, e o Databricks fará o resto.
# MAGIC
# MAGIC Embora isso seja feito usando a interface do usuário, você também pode aproveitar a [API Python](https://docs.databricks.com/en/machine-learning/automl/train-ml-model-automl-api.html)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Usando AutoML com tabelas de recursos rotulados
# MAGIC
# MAGIC [AutoML](https://docs.databricks.com/en/machine-learning/automl/how-automl-works.html) funciona em uma tabela de entrada com recursos preparados e os rótulos correspondentes. Para esta demonstração rápida, é isso que faremos. Executamos o AutoML na tabela `catalogo.schema.mlops_churn_training` e capturamos a linhagem da tabela no momento do treinamento.
# MAGIC
# MAGIC #### Usando AutoML com tabelas no Feature Store
# MAGIC
# MAGIC AutoML também funciona com tabelas que contêm apenas os rótulos verdadeiros e as une com tabelas de recursos no Feature Store. Isso será ilustrado em uma demonstração mais avançada.
# MAGIC
# MAGIC Você pode unir/usar recursos diretamente do Feature Store a partir da [UI](https://docs.databricks.com/machine-learning/automl/train-ml-model-automl-ui.html#use-existing-feature-tables-from-databricks-feature-store) ou [API Python](https://docs.databricks.com/en/machine-learning/automl/train-ml-model-automl-api.html#automl-experiment-with-feature-store-example-notebook)
# MAGIC * Selecione a tabela contendo os rótulos verdadeiros
# MAGIC * Una os recursos restantes da tabela de recursos

# COMMAND ----------

churn_features = spark.read.table(training_table)
churn_features.display()

# COMMAND ----------

# DBTITLE 1,Execute o experimento 'baseline' de AutoML
from databricks import automl
from datetime import datetime

xp_path = f"/Workspace/Shared/workshops_databricks/experiments/rodrigo.oliveira@databricks.com/"
xp_name = f"churn_model_rodrigo"

# Adicionar/Forçar tipos de dados semânticos para colunas específicas (para facilitar o autoML e garantir que não seja interpretado como categórico)
churn_features = churn_features.withMetadata("num_optional_services", {"spark.contentAnnotation.semanticType":"numeric"})

# métrica_primária padrão = "f1_score"
automl_run = automl.classify(
    experiment_name = xp_name,
    experiment_dir = xp_path,
    dataset = churn_features,
    primary_metric = "roc_auc",
    target_col = "churn",
    #split_col = "split", #Isso requer DBRML 15.3+
    timeout_minutes = 5,
    exclude_cols ='customer_id'
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Usando o notebook gerado para construir nosso modelo
# MAGIC
# MAGIC Próximo passo: [Explore o notebook Auto-ML gerado]($./03_automl_best_run)
# MAGIC
# MAGIC **Nota:**
# MAGIC Para fins de demonstração, execute o notebook acima para criar e registrar uma nova versão do modelo a partir do seu experimento autoML e rotule/alcunhe o modelo como "Champion"