# Databricks notebook source
# MAGIC %md
# MAGIC # Inferência do Modelo de Previsão de Churn
# MAGIC
# MAGIC ## Inferência com o modelo Champion
# MAGIC
# MAGIC Com Modelos no Unity Catalog, eles podem ser carregados para uso em pipelines de inferência em lote. As previsões geradas podem ser usadas para elaborar estratégias de retenção de clientes ou para análises. O modelo em uso é o modelo __Champion__, e nós o carregaremos para uso em nosso pipeline.
# MAGIC
# MAGIC <img src="https://github.com/databricks-demos/dbdemos-resources/blob/main/images/product/mlops/mlops-uc-end2end-5.png?raw=true" width="1200">
# MAGIC
# MAGIC <!-- Coletar dados de uso (visualização). Remova para desativar a coleta ou desative o rastreador durante a instalação. Veja o README para mais detalhes. -->
# MAGIC <img width="1px" src="https://ppxrzfxige.execute-api.us-west-2.amazonaws.com/v1/analytics?category=data-science&org_id=984752964297111&notebook=%2F01-mlops-quickstart%2F05_batch_inference&demo_name=mlops-end2end&event=VIEW&path=%2F_dbdemos%2Fdata-science%2Fmlops-end2end%2F01-mlops-quickstart%2F05_batch_inference&version=1">

# COMMAND ----------

# MAGIC %md
# MAGIC A próxima célula demora em média 1 minuto.

# COMMAND ----------

# MAGIC %run ../_resources/00-setup

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("catalog", catalog_prod)
dbutils.widgets.text("schema", schema)
training_table = f"{catalog_dev}.{schema}.churn_training"

# COMMAND ----------

# MAGIC %md
# MAGIC `Verifique no catalogo se a tabela: churn_inference foi criada`

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Implantando o modelo para inferências em lote
# MAGIC
# MAGIC <!--img style="float: right; margin-left: 20px" width="600" src="https://github.com/QuentinAmbard/databricks-demo/raw/main/retail/resources/images/churn_batch_inference.gif" /-->
# MAGIC
# MAGIC Agora que nosso modelo está disponível no Unity Catalog Model Registry, podemos carregá-lo para calcular nossas inferências e salvá-las em uma tabela para começar a construir dashboards.
# MAGIC
# MAGIC Usaremos a função MLFlow para carregar um UDF pyspark e distribuir nossa inferência em todo o cluster. Se os dados forem pequenos, também podemos carregar o modelo com python puro e usar um DataFrame pandas.
# MAGIC
# MAGIC Se você não souber por onde começar, pode obter um código de exemplo na página __"Artifacts"__ da execução do experimento do modelo.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Execute inferências

# COMMAND ----------

from mlflow.store.artifact.models_artifact_repo import ModelsArtifactRepository

requirements_path = ModelsArtifactRepository(f"models:/{catalog_prod}.{schema}.churn_model@Champion").download_artifacts(artifact_path="requirements.txt")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Inferência em lote no modelo Champion
# MAGIC
# MAGIC Estamos prontos para executar a inferência no modelo Champion. Vamos carregar o modelo como um UDF do Spark e gerar previsões para nossos registros de clientes.
# MAGIC
# MAGIC Para simplificar, assumimos que as características foram extraídas para os novos registros de clientes e que estas já estão armazenadas na tabela de características. Isso é tipicamente feito por pipelines de engenharia de características separadas.

# COMMAND ----------

import mlflow.pyfunc
from pyspark.sql.functions import lit, struct

# Carregar características dos clientes para pontuação
inference_df = spark.read.table(f"{catalog_prod}.{schema}.churn_training")

# Adicionar a coluna predict com valores nulos
inference_df = inference_df.withColumn('predict', lit(None))

# Carregar modelo campeão
champion_model = mlflow.pyfunc.load_model(model_uri=f"models:/{catalog_prod}.{schema}.churn_model@Champion")

# Predict
preds_df = champion_model.predict(inference_df.toPandas())

preds_df

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC É isso! Nossos dados agora podem ser salvos como uma tabela e reutilizados pela equipe de Análise de Dados / Marketing para tomar ações especiais e reduzir o risco de Churn desses clientes!
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Implantando modelo AutoML para serviço em tempo real
# MAGIC
# MAGIC Vamos implantar nosso modelo por trás de uma API escalável para avaliar a probabilidade de fraude em milissegundos e reduzir fraudes em tempo real.
# MAGIC
# MAGIC ## Serviço de Modelos Databricks
# MAGIC
# MAGIC Agora que nosso modelo foi criado com o Databricks AutoML, podemos facilmente marcá-lo como Pronto para Produção e ativar o Serviço de Modelos Databricks.
# MAGIC
# MAGIC Poderemos enviar Requisições HTTP e obter inferências em tempo real.
# MAGIC
# MAGIC O Serviço de Modelos Databricks é totalmente sem servidor:
# MAGIC
# MAGIC * Implantação com um clique. O Databricks cuidará da escalabilidade, proporcionando inferências extremamente rápidas e tempo de inicialização.
# MAGIC * Escala para zero como uma opção para o melhor TCO (será desligado se o endpoint não for usado)
# MAGIC * Suporte embutido para múltiplos modelos e versões implantadas
# MAGIC * Teste A/B e fácil atualização, roteando o tráfego entre cada versão enquanto mede o impacto
# MAGIC * Métricas e monitoramento embutidos

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ## Criando nosso endpoint de Servir Modelos
# MAGIC
# MAGIC <img src="https://raw.githubusercontent.com/databricks-demos/dbdemos-resources/main/images/fsi/fraud-detection/fsi-fraud-model-serving-ui.png" style="float: right; margin-left: 10px" width="400px"/>
# MAGIC
# MAGIC Vamos iniciar nosso Endpoint de Servir Modelos Serverless do Databricks.
# MAGIC
# MAGIC Para fazer isso com a interface, certifique-se de que você está na Persona "Machine Learning" (canto superior esquerdo) e selecione Abrir seu <a href="#mlflow/endpoints" target="_blank">"Servir Modelos"</a>.
# MAGIC
# MAGIC Em seguida, selecione o modelo que criamos e a última versão disponível.
# MAGIC
# MAGIC Além disso, permitiremos que o endpoint escale para zero (o endpoint será desligado após alguns minutos sem solicitações). Como é serverless, ele poderá reiniciar em poucos segundos.
# MAGIC
# MAGIC *Observe que o tempo de inicialização inicial levará alguns segundos extras enquanto a imagem do contêiner do modelo está sendo construída. Ela é então salva para garantir um tempo de inicialização mais rápido.*

# COMMAND ----------

model_name = f"{catalogo}.{schema}.churn_model"
model_name

# COMMAND ----------

# MAGIC %md
# MAGIC `Essa próxima etapa levará aproximadamente 12 minutos`

# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import EndpointCoreConfigInput, ServedModelInput, AutoCaptureConfigInput, ServedModelInputWorkloadSize
from mlflow import MlflowClient

serving_endpoint_name = "churn_endpoint_" + unique_name()
w = WorkspaceClient()

mlflow_client = MlflowClient(registry_uri="databricks-uc")
endpoint_config = EndpointCoreConfigInput(
    served_models=[
        ServedModelInput(
            model_name=model_name,
            model_version=mlflow_client.get_model_version_by_alias(model_name, "Champion").version,
            scale_to_zero_enabled=True,
            workload_size=ServedModelInputWorkloadSize.SMALL
        )
    ],
    auto_capture_config=AutoCaptureConfigInput(
        catalog_name=catalog_dev,
        schema_name=schema,
        enabled=True,
        table_name_prefix="churn_endpoint_inference_table"
    )
)

force_update = False
try:
    existing_endpoint = w.serving_endpoints.get(serving_endpoint_name)
    print(f"Endpoint {serving_endpoint_name} exists...")
    if force_update:
        w.serving_endpoints.update_config_and_wait(
            name=serving_endpoint_name,
            served_models=endpoint_config.served_models
        )
except Exception as e:
    print(f"Creating endpoint {serving_endpoint_name}...")
    spark.sql(f'DROP TABLE IF EXISTS {catalog_dev}.{schema}.churn_endpoint_inference_table')
    w.serving_endpoints.create_and_wait(
        name=serving_endpoint_name,
        config=endpoint_config
    )

# COMMAND ----------

# DBTITLE 1,Running HTTP REST inferences in realtime !
from mlflow.store.artifact.models_artifact_repo import ModelsArtifactRepository
from mlflow.models.model import Model

p = ModelsArtifactRepository(f"models:/{model_name}@Champion").download_artifacts("") 
dataset =  {"dataframe_split": Model.load(p).load_input_example(p).to_dict(orient='split')}

# COMMAND ----------

dataset

# COMMAND ----------

import mlflow
from mlflow import deployments
client = mlflow.deployments.get_deploy_client("databricks")
predictions = client.predict(endpoint=serving_endpoint_name, inputs=dataset)

print(predictions)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Agora temos nossa primeira versão do modelo disponível em produção para inferência em tempo real!
# MAGIC
# MAGIC Agora podemos começar a usar a API do endpoint para enviar consultas e começar a detectar fraudes em potencial em tempo real.
# MAGIC
# MAGIC Normalmente, adicionaríamos um desafio de segurança extra se o modelo considerar que isso é uma fraude em potencial.
# MAGIC
# MAGIC Isso permitiria um fluxo de transação simples, sem atrito para o cliente quando o modelo estiver confiante de que não é uma fraude, e adicionar mais camadas de segurança quando sinalizarmos como uma fraude em potencial.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Conclusão
# MAGIC
# MAGIC Isso é tudo para a demonstração rápida! Vimos os conceitos básicos de MLOps e como o Databricks ajuda você a alcançá-los. Eles incluem:
# MAGIC
# MAGIC - Engenharia de características e armazenamento de tabelas de características com rótulos no Databricks
# MAGIC - AutoML, treinamento de modelos e rastreamento de experimentos no MLflow
# MAGIC - Registro de modelos como Modelos no Unity Catalog para uso governado
# MAGIC - Validação de modelos, testes Champion-Challenger e promoção de modelos
# MAGIC - Inferência em lote carregando o modelo como um UDF do pySpark
# MAGIC
# MAGIC Esperamos que você tenha gostado desta demonstração. Como próximo passo, fique atento à nossa demonstração avançada de MLOps de ponta a ponta, que incluirá tutoriais mais detalhados sobre os seguintes aspectos do MLOps:
# MAGIC
# MAGIC - Servir características e Feature Store
# MAGIC - Monitoramento de dados e modelos
# MAGIC - Implantação para inferência em tempo real