# Databricks notebook source
# MAGIC %md
# MAGIC # Gerenciando o ciclo de vida do modelo no Unity Catalog
# MAGIC
# MAGIC Um dos principais desafios entre cientistas de dados e engenheiros de ML é a ausência de um repositório central para modelos, suas versões e os meios para gerenciá-los ao longo de seu ciclo de vida.
# MAGIC
# MAGIC [Modelos no Unity Catalog](https://docs.databricks.com/en/mlflow/models-in-uc.html) aborda esse desafio e permite que os membros da equipe de dados:
# MAGIC <br>
# MAGIC * **Descubram** modelos registrados, aliases atuais no desenvolvimento de modelos, execuções de experimentos e código associado a um modelo registrado
# MAGIC * **Promovam** modelos para diferentes fases de seu ciclo de vida com o uso de aliases de modelo
# MAGIC * **Etiquetem** modelos para capturar metadados específicos do seu processo de MLOps
# MAGIC * **Implantem** diferentes versões de um modelo registrado, oferecendo aos engenheiros de MLOps a capacidade de implantar e conduzir testes de diferentes versões de modelos
# MAGIC * **Testem** modelos de forma automatizada
# MAGIC * **Documentem** modelos ao longo de seu ciclo de vida
# MAGIC * **Protejam** o acesso e a permissão para registros, execuções ou modificações de modelos
# MAGIC
# MAGIC Vamos ver como testamos e promovemos um novo modelo __Challenger__ como candidato para substituir um modelo __Champion__ existente.
# MAGIC
# MAGIC <img src="https://github.com/databricks-demos/dbdemos-resources/blob/main/images/product/mlops/mlops-uc-end2end-3.png?raw=true" width="1200">
# MAGIC
# MAGIC <!-- Coletar dados de uso (visualização). Remova para desativar a coleta ou desative o rastreador durante a instalação. Veja o README para mais detalhes. -->
# MAGIC <img width="1px" src="https://ppxrzfxige.execute-api.us-west-2.amazonaws.com/v1/analytics?category=data-science&org_id=984752964297111&notebook=%2F01-mlops-quickstart%2F03_from_notebook_to_models_in_uc&demo_name=mlops-end2end&event=VIEW&path=%2F_dbdemos%2Fdata-science%2Fmlops-end2end%2F01-mlops-quickstart%2F03_from_notebook_to_models_in_uc&version=1">

# COMMAND ----------

# MAGIC %md
# MAGIC ## Como usar Modelos no Unity Catalog
# MAGIC Normalmente, cientistas de dados que usam MLflow conduzirão muitos experimentos, cada um com várias execuções que rastreiam e registram métricas e parâmetros. Durante o ciclo de desenvolvimento, eles selecionarão a melhor execução dentro de um experimento e registrarão seu modelo no Unity Catalog. Pense nisso como **cometer** o modelo ao Unity Catalog, assim como você cometeria código a um sistema de controle de versão.
# MAGIC
# MAGIC O Unity Catalog propõe alias de modelo de texto livre, ou seja, `Baseline`, `Challenger`, `Champion`, juntamente com a etiquetagem.
# MAGIC
# MAGIC Usuários com permissões apropriadas podem criar modelos, modificar aliases e etiquetas, usar modelos, etc.

# COMMAND ----------

# DBTITLE 1,Install MLflow version for model lineage in UC [for MLR < 15.2]
# %pip install --quiet mlflow==2.14.0
# dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ../_resources/00-setup

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("catalog", catalog_prod)
dbutils.widgets.text("schema", schema)
training_table = f"{catalog_dev}.{schema}.churn_training"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Encontre a melhor execução programaticamente e envie o modelo para o Catálogo Unity para validação
# MAGIC
# MAGIC Concluímos as execuções de treinamento para encontrar um modelo __Challenger__ candidato. Selecionaremos programaticamente o melhor modelo do nosso último experimento de ML e o registraremos no Catálogo Unity. Podemos fazer isso facilmente usando a API `search_runs` do MLFlow:

# COMMAND ----------

# Vamos obter nossa melhor execução de ML
best_model = mlflow.search_runs(
  experiment_ids="841205472890841", # buscar experimentID
  order_by=["metrics.test_f1_score DESC"],
  max_results=1,
  #filter_string="status = 'FINISHED' and run_name='mlops_best_run'" # filtrar em mlops_best_run para sempre usar o notebook 02 para ter uma demonstração mais previsível
)
# Opcional: Carregar o Experimento MLflow como um dataframe Spark e ver todas as execuções
# df = spark.read.format("mlflow-experiment").load(experiment_id)
best_model

# COMMAND ----------

artifact_uri = best_model.iloc[0]['artifact_uri']
artifact_uri

# Register the model in Unity Catalog
#model_details = mlflow.register_model(artifact_uri, model_name)

# COMMAND ----------

# MAGIC %md Uma vez que temos nosso melhor modelo, podemos registrá-lo no Unity Catalog Model Registry usando seu ID de execução

# COMMAND ----------

print(f"Registering model to {model_name}")  # {model_name} é definido no script de configuração

# Obter o run id do melhor modelo
run_id = best_model.iloc[0]['run_id']

# Registrar o melhor modelo das execuções de experimentos no registro de modelos do MLflow
model_details = mlflow.register_model(f"runs:/{run_id}/model", model_name)

# COMMAND ----------

# MAGIC %md
# MAGIC Neste ponto, o modelo ainda não possui nenhum alias ou descrição que indique seu ciclo de vida e meta-dados/informações. Vamos atualizar essas informações.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Dê uma descrição ao modelo registrado
# MAGIC
# MAGIC Faremos isso para o modelo registrado como um todo.

# COMMAND ----------

from mlflow import MlflowClient

client = MlflowClient()

# A descrição principal do modelo, normalmente feita uma vez.
client.update_registered_model(
  name=model_details.name,
  description="Este modelo prevê se um cliente irá cancelar usando os recursos da tabela mlops_churn_training. Ele é usado para alimentar o Churn Dashboard no DB SQL.",
)

# COMMAND ----------

# MAGIC %md
# MAGIC E adicione mais alguns detalhes sobre a nova versão que acabamos de registrar

# COMMAND ----------

# Forneça mais detalhes sobre esta versão específica do modelo
best_score = best_model['metrics.val_roc_auc'].values[0]
run_name = best_model['tags.mlflow.runName'].values[0]
version_desc = f"Esta versão do modelo possui uma métrica de validação Roc AUC de {round(best_score,4)*100}%. Siga o link para sua execução de treinamento para mais detalhes."

client.update_model_version(
  name=model_details.name,
  version=model_details.version,
  description=version_desc
)

# Também podemos marcar a versão do modelo com a pontuação Roc AUC para visibilidade
client.set_model_version_tag(
  name=model_details.name,
  version=model_details.version,
  key="roc_auc",
  value=f"{round(best_score,4)}"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Defina a versão mais recente do modelo como o modelo Challenger
# MAGIC
# MAGIC Vamos definir esta nova versão registrada do modelo como o modelo __Challenger__. Modelos Challenger são modelos candidatos a substituir o modelo Champion, que é o modelo atualmente em uso.
# MAGIC
# MAGIC Usaremos o alias do modelo para indicar o estágio em que ele se encontra em seu ciclo de vida.

# COMMAND ----------

# Defina esta versão como o modelo Challenger, usando seu alias de modelo
client.set_registered_model_alias(
  name=model_name,
  alias="Challenger",
  version=model_details.version
)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Agora, inspecione visualmente as versões do modelo no Unity Catalog Explorer. Você deve ver a descrição da versão e o alias `Challenger` aplicado à versão.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Próximo: Validação do modelo Challenger
# MAGIC
# MAGIC Neste ponto, com o modelo __Challenger__ registrado, gostaríamos de validar o modelo. As etapas de validação são implementadas em um notebook, para que o processo de validação possa ser automatizado como parte de um trabalho do Databricks Workflow.
# MAGIC
# MAGIC Se o modelo passar em todos os testes, ele será promovido a `Champion`.
# MAGIC
# MAGIC Próximo: Descubra como o modelo está sendo testado antes de ser promovido a `Champion` [usando o notebook de validação do modelo]($./04_challenger_validation)